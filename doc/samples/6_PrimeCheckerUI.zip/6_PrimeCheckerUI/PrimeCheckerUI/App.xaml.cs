﻿using System.Windows;

namespace TestAsyncUI
{
    public partial class App : Application
    {
    }
}
